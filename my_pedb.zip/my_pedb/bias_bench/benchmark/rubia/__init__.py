from .rubia import RuBiaRunner


#! unzip lmppl-main.zip
#! sudo apt-get install python3.10-dev

#sh = """
#cd lmppl-main
#pip install .
#"""
#with open('script.sh', 'w') as file:
#  file.write(sh)

#! bash script.sh