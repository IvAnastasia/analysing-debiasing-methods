import pandas as pd
df = pd.read_csv('/Users/azadi/Documents/NLP/диплом/pedb/data/crows/crows_pairs_anonymized.csv')
print(df.head())